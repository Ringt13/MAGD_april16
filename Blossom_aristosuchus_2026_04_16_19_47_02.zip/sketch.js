function setup() {
  createCanvas(128, 128);
}

function draw() {
  background(130);
  
stroke ('rgb(160,160,160)')
  fill (155)
 circle(64,34,55);
  
// the moon
  stroke('rgb(175,175,175)')
ellipseMode(RADIUS);
fill(255);
// ellipse(centerX, centerY, horizontalRadius, verticalRadius);
// recall that radius = diameter / 2
ellipse(20, 20, 20, 20);
  
  ellipseMode(RADIUS);
fill(230);
ellipse(10, 15, 5, 5);
  
  ellipseMode(RADIUS);
fill(220);
ellipse(30,24, 3, 3);
   //"stars" below
  
stroke('rgb(255,255,255)')
  
  strokeWeight(2)
  point(7,40)
  
  strokeWeight(2)
  point(100,20)
  
  strokeWeight(2)
  point(7,40)
  
  strokeWeight(2)
  point(9,10)
  
  strokeWeight(2)
  point(50,9)
  
  strokeWeight(2)
  point(120,12)
  
  strokeWeight(3)
  point(50,30)
  
  point(60,20)
  
  strokeWeight(2)
  point(85,12)
  
  stroke('rgb(189,189,189)')
  strokeCap(ROUND);
  line(130,10,50,50)

  stroke('black')
// "buildings" below
  rectMode(CORNER);
  strokeWeight(1);
  fill(20);
 // rect(topLeftCornerX, topLeftCornerY, width, height);
 rect(0,50,17, 128);
  
  rectMode(CORNER);
  strokeWeight(1);
  fill(40);
  rect(17, 30,17, 128);
  
  rectMode(CORNER);
  strokeWeight(1);
  fill(35);
  rect(30,60,30,100);
  
  rectMode(CORNER);
  strokeWeight(1);
  fill(20);
  rect(60,30,40,100);
  
  rectMode(CORNER);
  strokeWeight(1);
  fill(44);
  rect(90,40,100,130);

}
