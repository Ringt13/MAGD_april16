function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(190);

  // Balloon #1
  colorMode(RGB, 255, 165, 255, 1);
  fill(130, 16, 236);
  stroke(25, 100, 0, 0.3);
  strokeWeight(2);
  ellipse(300, 200, 80, 90);
  //triangle(x1, y1, x2, y2, x3, y3
  triangle(300, 240, 330, 260, 270, 260);

  // Balloon #2
  colorMode(RGB, 255, 255, 255, 1);
  fill(24, 44, 230);
  stroke(25, 100, 0, 0.3);
  strokeWeight(2);
  ellipse(200, 60, 80, 90);
  triangle(200, 100, 220, 120, 175, 120);

  // Draw a black bezier curve.
  noFill();
  stroke(0);
  strokeWeight(1);
  bezier(300, 100, 100, 200, 330, 100, 200, 120);

  fill(24, 30, 170);
  stroke(25, 60, 170);
  ellipse(195, 60, 50, 60);

  strokeWeight(2);
  stroke("rgb(107,118,253)");
  arc(195, 60, 50, 70, 20, PI + HALF_PI);
}
