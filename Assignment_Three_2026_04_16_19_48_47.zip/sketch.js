let mx = 0;
let my = 0;
let px = 0;
let py = 0;
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(200);
  
  colorMode(RGB,255)
   fill(100,255,255)
   // Style the text.
  textAlign(CENTER);
  textSize(16);

  // Display the mouse's coordinates.
  text(`x: ${mouseX} y: ${mouseY}`, 50, 50);

 // Adjust coordinates for WebGL mode.
  // The origin (0, 0) is at the center of the canvas.
  let pmx = pmouseX - 50;
  let pmy = pmouseY - 50;
  let mx = mouseX - 50;
  let my = mouseY - 50;

  fill('rgba(0, 255, 0, 0.25)');;
  // Draw the line.
   line(pmouseX, pmouseY, mouseX, mouseY);
  
   line(200, 0, 200, 400);

  // Calculate the mouse's distance from the middle.
  let h = abs(mouseX - 20);

  // Draw a rectangle based on the mouse's distance
  // from the middle.
  rect(200, 400 - 400, 400, h);
  
  fill(255,100,255)
    // Calculate the angle conversion.
  let deg = 45;
  let rad = radians(deg);

  // Display the angle conversion.
  text(`${deg}˚ = ${round(rad, 3)} rad`, 60, 100);

}